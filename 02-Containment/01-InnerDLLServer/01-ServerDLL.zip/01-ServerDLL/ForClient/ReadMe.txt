1) Include the header file in your source code. Interfaces, their functionalities and    
   respective GUIDs are given in the header file. Use them accordingly.

2) Keep the dll at C:\Windows\System32 path.

3) Double click on the reg file to register the dll.

4) Now build and run your program.